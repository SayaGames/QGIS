# RasterTiler

The RasterTiler is a free open source plugin for QGIS that allows for tiling of remote sensing images. Also, it provides geojson file contains tiled images' properties as an output. Such as MGRS code, coordinates, tile index. 

## Using the plugin

To use this plugin you just need to install it using the QGIS interface.

Choose input image and output folder

Adjust tilesize and buffer sizes

Press Start Button to run


## Contributing to the development

If you find some issue that you are willing to fix, code contributions are welcome. Please e-mail to:msunsuli@gmail.com 

## Author

* **Mete Sünsüli** 

## License

This plugin is distributed under a GNU General Public License version 3.
