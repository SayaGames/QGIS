#----GENEL ÖZELLİKLER---
# Projection
#ds.GetProjection()

# Dimensions
#ds.RasterXSize # veya band_r.XSize şeklinde bant bant alınabilir. 
#ds.RasterYSize

# Bant sayısı
#ds.RasterCount

# Metadata for the raster dataset
#ds.GetMetadata()


#Dataset >> Band

import os
from os import path
import sys
import inspect
import gdal
from .mgrs import LLtoMGRS 
from qgis.core import QgsProject, Qgis
from PyQt5.QtWidgets import QFileDialog
from PyQt5.QtWidgets import QAction
from PyQt5.QtGui import QIcon

from .RasterTilerDialog import RasterTilerDialog

cmd_folder = os.path.split(inspect.getfile(inspect.currentframe()))[0]
file = ""

class RasterTiler:
    def __init__(self, iface):
        self.iface = iface
        self.inPath = ""
        self.outPath = ""
        self.inFileName = ""
        
        

    def initGui(self):
        icon = os.path.join(os.path.join(cmd_folder, 'RasterTilerPlugin.png'))
        self.action = QAction(QIcon(icon), 'Raster Tile', self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToRasterMenu('&Raster Tile', self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu('&RasterTiler', self.action)  
        del self.action
      
    def choose_file_location(self):
        filename = "/"
        filename, _filter = QFileDialog.getOpenFileName(self.dlg, "Choose a file... ","", '*.tif')
        self.dlg.lineEditDirectory.setText(filename)
        if filename.strip() != "":
            self.inPath = filename[:filename.rindex('/')] + '/'
            self.inFileName = filename[filename.rindex('/') + 1:]
            self.dlg.pushButtonBrowseOut.setEnabled(True)
            
        #self.iface.messageBar().pushMessage('Success',  self.inFileName, level=Qgis.Success)
        #self.dlg.btnStart.setEnabled(True)
        
    def choose_file_location_out(self):
        outDirectory = "/"
        outDirectory = QFileDialog.getExistingDirectory(self.dlg, "Choose a directory... ")
        self.dlg.lineEditDirectoryOut.setText(outDirectory)
        if outDirectory.strip() != "":
            self.outPath = outDirectory + '/'
        if self.inFileName.strip() !="":
            self.dlg.btnStart.setEnabled(True)
    
    def run(self):   
        self.dlg = RasterTilerDialog()
        self.dlg.pushButtonBrowse.clicked.connect(self.choose_file_location)
        self.dlg.pushButtonBrowseOut.clicked.connect(self.choose_file_location_out)
        self.dlg.btnStart.clicked.connect(self.rasterTile)
        
        self.dlg.lineEditDirectory.clear()
        self.dlg.show()
      
        result = self.dlg.exec_()
        if result:
            a = self.dlg.lineEditDirectory.text()
            
    
  
    def giveMeMessage(self):
        self.iface.messageBar().pushMessage('Success', 'Check the folder for tif and json: ' + file, level=Qgis.Success)
        
    def rasterTile(self):
        from datetime import datetime
        
        #self.iface.messageBar().pushMessage('Success', self.dlg.lineEditDirectory.text()[:self.dlg.lineEditDirectory.text().rindex('/')] + '/', level=Qgis.Success)
        
        start = datetime.now()

        print("START: " , datetime.now().strftime("%m/%d/%Y, %H:%M:%S"))

        inPath =self.inPath #'D:/DOC-PRJ/SPLIT/IN/RST_20190117_bd3_3_L2/2/'
        inFilename = self.inFileName
        if os.path.exists(self.outPath) == False:
            os.mkdir(self.outPath)
        
        outPath = self.outPath    #'D:/DOC-PRJ/SPLIT/'
        outFile = 'T_'
        outOffsetFile = 'X_'

        bandNr = 1
         
        tileSizeX = int(self.dlg.lineEditTileX.text()) #256
        tileSizeY = int(self.dlg.lineEditTileY.text()) #256
        offsetSizeX = int(self.dlg.lineEditTileXOffset.text()) #128
        offsetSizeY = int(self.dlg.lineEditTileYOffset.text()) #128
     
        ds = gdal.Open(inPath + inFilename)



        bandR = ds.GetRasterBand(bandNr) # TODO Bu Red band sonrasında for ile 3 bant çek ds.RasterCount
        xsize = bandR.XSize
        ysize = bandR.YSize

#        totalSize = xsize * ysize
#        tileSize = tileSizeX * tileSizeY
#        totalCount = int(totalSize/tileSize)
        #bandR.ComputeStatistics(0)
        #bandR.GetNoDataValue()
        #
        #dsArray = ds.ReadAsArray()

        geojson = "{\n\t\"type\": \"FeatureCollection\",\n\t\"features\": ["
        counter = 0
        for i in range(0, xsize, tileSizeX):
            for j in range(0, ysize, tileSizeY):
                #[0,0],[0,256],[256,256],[256,0],[0,0]
           
        #        print("[" \
        #        + str(i) + "," + str(j) + "],[" \
        #        + str(i) + "," + str(j + tileSizeY) + "],[" \
        #        + str(i + tileSizeX) + "," + str(j + tileSizeY) + "],[" \
        #        + str(i + tileSizeX) + "," + str(j) + "],["  \
        #        + str(i) + "," + str(j) + "]\n")
        #        
                
        #        + str(i) + "," + str(j) + "],[" \
        #        + str(i) + "," + str(j + tileSizeY) + "],[" \
        #        + str(i + tileSizeX) + "," + str(j + tileSizeY) + "],[" \
        #        + str(i + tileSizeX) + "," + str(j) + "],["  \
        #        + str(i) + "," + str(j) + "]"
                
                t = gdal.Translate(str(outPath) + str(outFile) + str(i) + "_" + str(j) + ".tif", ds, options="-of GTIFF -srcwin " + str(i)+ ", " + str(j) + ", " + str(tileSizeX) + ", " + str(tileSizeY) )
        #        gdal.Translate(str(outPath) + str(outFile) + str(i) + "_" + str(j) + ".tif", ds, options="-of GTIFF -srcwin " + str(i - offsetSizeX)+ ", " + str(j - offsetSizeY) + ", " + str(tileSizeX) + ", " + str(tileSizeY) )
                gt = t.GetGeoTransform()
        #        cols = t.RasterXSize
        #        rows = t.RasterYSize
                
                minx = gt[0]
                maxy = gt[3]
                maxx = minx + gt[1] * t.RasterXSize
                miny = maxy + gt[5] * t.RasterYSize
        #        print (minx, miny, maxx, maxy)
                #print(LLtoMGRS(minx,miny))
                
                geojson +="\n\t\t{\"type\": \"Feature\",\n\t\t\t\"properties\": {"
                geojson +="\n\t\t\t\t\"id\": \"" + str(outFile) + str(i) + "_" + str(j) + "\"\n\t\t\t\t,"
                geojson +="\n\t\t\t\t\"mgrscode\": \"" + LLtoMGRS(minx,miny) + "\"\n\t\t\t\t},"
                geojson += "\n\t\t\t\t\"geometry\":{"
                geojson += "\n\t\t\t\t\t\"type\": \"Polygon\","
                geojson += "\n\t\t\t\t\t\"coordinates\": [["
                geojson += "\n\t\t\t\t\t\t[" 
                
                geojson += str(minx) + "," + str(miny) + "],[" \
                + str(minx) + "," + str(maxy) + "],[" \
                + str(maxx) + "," + str(maxy) + "],[" \
                + str(maxx) + "," + str(miny) + "],["  \
                + str(minx) + "," + str(miny) + "]"
            
            
                geojson+="\n\t\t]]}},"
                
     # Offsetli tile
                if (offsetSizeX > 0 and offsetSizeY > 0) :
                    t = gdal.Translate(str(outPath) + str(outOffsetFile) + str(i) + "_" + str(j) + ".tif", ds, options="-of GTIFF -srcwin " + str(i - offsetSizeX)+ ", " + str(j - offsetSizeY) + ", " + str(tileSizeX) + ", " + str(tileSizeY) )
                    
                    gt = t.GetGeoTransform()
            #        cols = t.RasterXSize
            #        rows = t.RasterYSize
                    
                    minx = gt[0]
                    maxy = gt[3]
                    maxx = minx + gt[1] * t.RasterXSize
                    miny = maxy + gt[5] * t.RasterYSize
            #        print (minx, miny, maxx, maxy)
                    #print(LLtoMGRS(minx,miny))
                    
                    geojson +="\n\t\t{\"type\": \"Feature\",\n\t\t\t\"properties\": {"
                    geojson +="\n\t\t\t\t\"id\": \"" + str(outOffsetFile) + str(i) + "_" + str(j) + "\"\n\t\t\t\t,"
                    geojson +="\n\t\t\t\t\"mgrscode\": \"" + LLtoMGRS(minx,miny) + "\"\n\t\t\t\t},"
                    geojson += "\n\t\t\t\t\"geometry\":{"
                    geojson += "\n\t\t\t\t\t\"type\": \"Polygon\","
                    geojson += "\n\t\t\t\t\t\"coordinates\": [["
                    geojson += "\n\t\t\t\t\t\t[" 
                    
                    geojson += str(minx) + "," + str(miny) + "],[" \
                    + str(minx) + "," + str(maxy) + "],[" \
                    + str(maxx) + "," + str(maxy) + "],[" \
                    + str(maxx) + "," + str(miny) + "],["  \
                    + str(minx) + "," + str(miny) + "]"
                    geojson+="\n\t\t]]}},"            
                    counter+=1
            
                counter+=1
                end = datetime.now()
                self.dlg.lblStatus.setText("Start: " + datetime.now().strftime("%m/%d/%Y, %H:%M:%S") + " \nCount: " + str(counter) + " \nElapsed: " + str((end - start))[:10])
                self.dlg.repaint()
                
        ds = None
        bandR = None

        geojson = geojson.strip(",")
        geojson += "\n\t]\n}"

        #print(geojson)

        f = open(outPath + inFilename + ".geojson", 'w')
        f.write(geojson)

        end = datetime.now()

        print("END: " , datetime.now().strftime("%m/%d/%Y, %H:%M:%S")," süre: " , str(end-start)) 
        print(outPath + inFilename + ".geojson")

    def main():
        rasterTiler()