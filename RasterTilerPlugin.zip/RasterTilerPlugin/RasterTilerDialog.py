import os

from PyQt5 import uic
from PyQt5 import QtWidgets

FORM_CLASS, _ = uic.loadUiType(os.path.join(str(os.path.dirname(__file__)), 'RasterTilerDialog.ui'))


class RasterTilerDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        super(RasterTilerDialog, self).__init__(parent)
        self.setupUi(self)
