from .RasterTiler import RasterTiler
def classFactory(iface):
    return RasterTiler(iface)
